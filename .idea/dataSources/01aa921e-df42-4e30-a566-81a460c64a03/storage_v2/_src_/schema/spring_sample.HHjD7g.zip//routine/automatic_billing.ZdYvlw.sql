create
    definer = root@localhost procedure automatic_billing(IN pIdClient int)
begin
    /*Vencimiento a quince días de la fecha facturada*/

    declare var_call_id int;
    declare var_call_total float;
    declare var_bill_total float default 0;
    declare var_calls_sum int default 0;
    declare var_generated_date date default now();
    declare var_expiration_date date default date_add(now(), interval 15 day);
    declare var_generated_bill_id int;
    declare var_finished int default 0;

    declare cur_billing cursor for
        select c.id, c.total
        from calls c
                 inner join clients cli on c.id_origin_phone = cli.id_phone
        where c.id_bill is null
          and cli.id = pIdClient;

    declare continue handler for not found set var_finished = 1;

    insert into bills (id_client, calls_sum, total, generated_date, expiration_date)
    values (pIdClient, var_calls_sum, var_bill_total, var_generated_date, var_expiration_date);

    set var_generated_bill_id = last_insert_id();

    open cur_billing;

    fetch cur_billing into var_call_id, var_call_total;

    while (var_finished = 0)
        do
            set var_calls_sum = var_calls_sum + 1;
            set var_bill_total = var_bill_total + var_call_total;
            update calls c set id_bill = var_generated_bill_id where c.id = var_call_id;
            fetch cur_billing into var_call_id, var_call_total;
        end while;

    if var_calls_sum = 0 then
        delete from bills b where b.id = var_generated_bill_id;

        signal sqlstate '45000' set message_text = 'The current client does not have any call to be billed';
    end if;

    update bills b set b.calls_sum = var_calls_sum, b.total = var_bill_total where b.id = var_generated_bill_id;

    close cur_billing;
end;

