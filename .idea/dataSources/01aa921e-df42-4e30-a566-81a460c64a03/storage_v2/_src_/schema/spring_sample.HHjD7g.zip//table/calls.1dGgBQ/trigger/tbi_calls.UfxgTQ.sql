create definer = root@localhost trigger TBI_calls
    before insert
    on calls
    for each row
begin
    declare var_id_origin_city int default 0;
    declare var_id_destination_city int default 0;
    declare var_origin_phone varchar(10);
    declare var_destination_phone varchar(10);
    declare var_id_fee int;
    declare var_cost float default 0;

    #Search for the phone numbers and do not validate because the id already came validated by the api
    select p.number into var_origin_phone from phones p where p.id = NEW.id_origin_phone;
    select p.number into var_destination_phone from phones p where p.id = NEW.id_destination_phone;

    #Search for the cities id (origin and destination)
    select c.id
    into var_id_origin_city
    from cities c
    where var_origin_phone like concat(c.area_code, '%')
      and length(c.area_code) =
          (select max(length(c2.area_code)) from cities c2 where var_origin_phone like concat(c2.area_code, '%'));

    select c.id
    into var_id_destination_city
    from cities c
    where var_destination_phone like concat(c.area_code, '%')
      and length(c.area_code) =
          (select max(length(c2.area_code)) from cities c2 where var_destination_phone like concat(c2.area_code, '%'));

    #Search for the fee id and the cost that belongs to the fee
    select f.id, f.cost
    into var_id_fee, var_cost
    from fees f
    where f.id_origin_city = var_id_origin_city
      and f.id_destination_city = var_id_destination_city
      and time(NEW.start_date) between f.start_time and f.end_time;

    if (var_cost = 0)
    then
        signal sqlstate '45000' set message_text = 'The call information does not match any fee in the data base';
    end if;

    set NEW.id_origin_city = var_id_origin_city;
    set NEW.id_destination_city = var_id_destination_city;
    set NEW.id_fee = var_id_fee;
    set NEW.total = (NEW.duration * var_cost) / 60;

end;

